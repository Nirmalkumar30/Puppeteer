import { Before, After, Status, BeforeAll, AfterAll } from "cucumber";
import { assert } from "chai";
import { loginPageElements } from '../locators/objectsRepository';
import { LoginPage  } from "../pages/BackBase/loginPage";
import { Helpers } from "../lib/helpers";
import { Config } from "../lib/config";
import * as fs from "fs";
import { LandingPage } from "../pages/BackBase/LandingPage";


var helpers = new Helpers();
var config = new Config();
var feature = '';
var loginPg =  new LoginPage();

BeforeAll({timeout: 50000},async function() {
    await helpers.launchBrowser();
     if (process.env.TAG == "@Articles" ) {
        await loginPg.loginApplication(config.baseUrl)
    } 
});

After({timeout: 50000},async function(scenario) {    
    if(scenario.result.status == Status.FAILED) {
        await this.attach(await helpers.takeScreenshot(), 'image/png');
    }
    if (process.env.TAG == "@Articles") {
        return;
    } else{
        await helpers.refreshBrowser();
        await helpers.loadUrl(process.env.BASEURL);
     }  
});

AfterAll({timeout: 50000}, async function(){
    await helpers.closeBrowser();
});

