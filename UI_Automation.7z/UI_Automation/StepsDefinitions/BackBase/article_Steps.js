"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const cucumber_1 = require("cucumber");
const chai_1 = require("chai");
const articlePage_1 = require("../../pages/BackBase/articlePage");
const LandingPage_1 = require("../../pages/BackBase/LandingPage");
const editorPage_1 = require("../../pages/BackBase/editorPage");
var editorPg = new editorPage_1.editorPage();
var LandingPg = new LandingPage_1.LandingPage();
var articlePg = new articlePage_1.articlePage();
cucumber_1.Given(/^User Click on New Post Link from TopNav$/, () => __awaiter(void 0, void 0, void 0, function* () {
    yield LandingPg.clickNewPost();
}));
cucumber_1.When(/^User enter the Artile Title as '([^\"]*)'$/, (artistTitle) => __awaiter(void 0, void 0, void 0, function* () {
    yield editorPg.enterArticleTitle(artistTitle);
}));
cucumber_1.When(/^User enter the Artile message as '([^\"]*)'$/, (articleMessage) => __awaiter(void 0, void 0, void 0, function* () {
    yield editorPg.enterArticleMessage(articleMessage);
}));
cucumber_1.When(/^User enter the Artile about as '([^\"]*)'$/, (artistAbout) => __awaiter(void 0, void 0, void 0, function* () {
    yield editorPg.enterArticleAbout(artistAbout);
}));
cucumber_1.When(/^User enter the Tag as '([^\"]*)'$/, (tag) => __awaiter(void 0, void 0, void 0, function* () {
    yield editorPg.enterTagName(tag);
}));
cucumber_1.Then(/^User Click on publish Article button$/, () => __awaiter(void 0, void 0, void 0, function* () {
    yield editorPg.clickPublishArticle();
}));
cucumber_1.Then(/User Verifies the Article '([^\"]*)' published successfully$/, (artistTitle) => __awaiter(void 0, void 0, void 0, function* () {
    yield chai_1.assert.strictEqual(yield articlePg.verifyTitleName(artistTitle), true);
}));
cucumber_1.When(/^User Click on User Profile '([^\"]*)' link from TopNav$/, (UserName) => __awaiter(void 0, void 0, void 0, function* () {
    yield LandingPg.clickUserName(UserName);
}));
cucumber_1.When(/User select the '([^\"]*)' article under My Article tab$/, (artistTitle) => __awaiter(void 0, void 0, void 0, function* () {
    yield articlePg.selectFirstArticle(artistTitle);
}));
cucumber_1.When(/User Click on Edit Article button$/, () => __awaiter(void 0, void 0, void 0, function* () {
    yield articlePg.clickEditArticle();
}));
cucumber_1.When(/User Click on delete Article button$/, () => __awaiter(void 0, void 0, void 0, function* () {
    yield articlePg.clickDeleteArticle();
}));
cucumber_1.Then(/User Verifies the Article message '([^\"]*)' edited and published successfully$/, (artistMessage) => __awaiter(void 0, void 0, void 0, function* () {
    yield chai_1.assert.strictEqual(yield articlePg.verifyArticleMessage(artistMessage), true);
}));
cucumber_1.When(/User select the '([^\"]*)' as a favoriate article under My Article tab$/, (artistTitle) => __awaiter(void 0, void 0, void 0, function* () {
    yield articlePg.selectFavorateArticle();
}));
cucumber_1.When(/User Click on Favoriate Article tab$/, () => __awaiter(void 0, void 0, void 0, function* () {
    yield articlePg.clickFavArticleTab();
}));
cucumber_1.Then(/User Verifies the article '([^\"]*)' delete successfully$/, (artistMessage) => __awaiter(void 0, void 0, void 0, function* () {
    yield chai_1.assert.strictEqual(yield articlePg.verifyArticleMessage(artistMessage), false);
}));
//# sourceMappingURL=article_Steps.js.map