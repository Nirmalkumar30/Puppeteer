"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const cucumber_1 = require("cucumber");
const chai_1 = require("chai");
const settingsPage_1 = require("../../pages/BackBase/settingsPage");
const LandingPage_1 = require("../../pages/BackBase/LandingPage");
var settingsPg = new settingsPage_1.settingsPage();
var LandingPg = new LandingPage_1.LandingPage();
cucumber_1.Given(/^User Click on settings Link from TopNav$/, () => __awaiter(void 0, void 0, void 0, function* () {
    yield LandingPg.clickSetting();
}));
cucumber_1.When(/^User modify the UserName as '([^\"]*)'$/, (userName) => __awaiter(void 0, void 0, void 0, function* () {
    yield settingsPg.enterUserName(userName);
}));
cucumber_1.Then(/^User Click on Update settings button$/, () => __awaiter(void 0, void 0, void 0, function* () {
    yield settingsPg.clickUpdate();
}));
cucumber_1.Then(/^Verify the UserName '([^\"]*)' updated successfully$/, (userName) => __awaiter(void 0, void 0, void 0, function* () {
    yield chai_1.assert.strictEqual(yield settingsPg.VerifyNewUserName(userName), true);
}));
cucumber_1.When(/^User enter shortBio as '([^\"]*)'$/, (bio) => __awaiter(void 0, void 0, void 0, function* () {
    yield settingsPg.enterShortBio(bio);
}));
cucumber_1.Then(/^Verify the Bio '([^\"]*)' updated successfully$/, (bio) => __awaiter(void 0, void 0, void 0, function* () {
    yield chai_1.assert.strictEqual(yield settingsPg.VerifyBio(bio), true);
}));
cucumber_1.When(/^User enter emailID as '([^\"]*)'$/, (emailID) => __awaiter(void 0, void 0, void 0, function* () {
    yield settingsPg.enterEmail(emailID);
}));
cucumber_1.Then(/^Verify the email '([^\"]*)' updated successfully$/, (bio) => __awaiter(void 0, void 0, void 0, function* () {
    yield chai_1.assert.strictEqual(yield settingsPg.verifyEmail(bio), true);
}));
//# sourceMappingURL=settingsSteps.js.map