import { Given, When, Then, TableDefinition } from "cucumber";
import { expect, assert } from "chai";
import { settingsPage } from "../../pages/BackBase/settingsPage";
import { LandingPage } from "../../pages/BackBase/LandingPage";

var settingsPg = new settingsPage();
var LandingPg = new LandingPage();


Given(/^User Click on settings Link from TopNav$/, async () => {
    await LandingPg.clickSetting()
});

When(/^User modify the UserName as '([^\"]*)'$/, async (userName) => {
    await settingsPg.enterUserName(userName)
});

Then(/^User Click on Update settings button$/, async () => {
    await settingsPg.clickUpdate()
});

Then(/^Verify the UserName '([^\"]*)' updated successfully$/, async (userName) => {
    await assert.strictEqual(await settingsPg.VerifyNewUserName(userName), true)
});

When(/^User enter shortBio as '([^\"]*)'$/, async (bio) => {
    await settingsPg.enterShortBio(bio)
});

Then(/^Verify the Bio '([^\"]*)' updated successfully$/, async (bio) => {
    await assert.strictEqual(await settingsPg.VerifyBio(bio), true)
});

When(/^User enter emailID as '([^\"]*)'$/, async (emailID) => {
    await settingsPg.enterEmail(emailID)
});

Then(/^Verify the email '([^\"]*)' updated successfully$/, async (bio) => {
    await assert.strictEqual(await settingsPg.verifyEmail(bio), true)
});

