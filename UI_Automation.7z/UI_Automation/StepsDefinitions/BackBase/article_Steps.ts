import { Given, When, Then, TableDefinition } from "cucumber";
import { expect, assert } from "chai";
import { articlePage } from "../../pages/BackBase/articlePage";
import { LandingPage } from "../../pages/BackBase/LandingPage";
import { editorPage } from "../../pages/BackBase/editorPage";

var editorPg = new editorPage();
var LandingPg = new LandingPage();
var articlePg = new articlePage();

Given(/^User Click on New Post Link from TopNav$/, async () => {
    await LandingPg.clickNewPost()
});

When(/^User enter the Artile Title as '([^\"]*)'$/, async (artistTitle) => {
    await editorPg.enterArticleTitle(artistTitle)
});

When(/^User enter the Artile message as '([^\"]*)'$/, async (articleMessage) => {
    await editorPg.enterArticleMessage(articleMessage)
});

When(/^User enter the Artile about as '([^\"]*)'$/, async (artistAbout) => {
    await editorPg.enterArticleAbout(artistAbout)
});

When(/^User enter the Tag as '([^\"]*)'$/, async (tag) => {
    await editorPg.enterTagName(tag)
});

Then(/^User Click on publish Article button$/, async () => {
    await editorPg.clickPublishArticle()
    
});

Then(/User Verifies the Article '([^\"]*)' published successfully$/, async (artistTitle) => {
    await assert.strictEqual(await articlePg.verifyTitleName(artistTitle), true)
});

When(/^User Click on User Profile '([^\"]*)' link from TopNav$/, async (UserName) => {
    await LandingPg.clickUserName(UserName)
});

When(/User select the '([^\"]*)' article under My Article tab$/, async (artistTitle) => {
    await articlePg.selectFirstArticle(artistTitle)
});

When(/User Click on Edit Article button$/, async () => {
    await articlePg.clickEditArticle();
});

When(/User Click on delete Article button$/, async () => {
    await articlePg.clickDeleteArticle();
});

Then(/User Verifies the Article message '([^\"]*)' edited and published successfully$/, async (artistMessage) => {
    await assert.strictEqual(await articlePg.verifyArticleMessage(artistMessage), true)
});

When(/User select the '([^\"]*)' as a favoriate article under My Article tab$/, async (artistTitle) => {
    await articlePg.selectFavorateArticle()
});

When(/User Click on Favoriate Article tab$/, async () => {
    await articlePg.clickFavArticleTab();
});

Then(/User Verifies the article '([^\"]*)' delete successfully$/, async (artistMessage) => {
    await assert.strictEqual(await articlePg.verifyArticleMessage(artistMessage), false)
});



