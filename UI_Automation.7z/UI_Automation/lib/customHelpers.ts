
var os = require('os');
var fileSystem = require('fs');
var path = require('path'),
_ = require('underscore');
var xlsxFile = require('read-excel-file/node');


export class CustomHelpers {
    /**
   * This function will read the actual values from latest downloaded excel then compare with expected value and return the result
   */
  async readFromExcel(expectedColumnName) { 
    var result;  
    var fileName =await this.getMostRecentDownloadedFileName();
    await console.log('C:/Users/'+os.userInfo().username+'/Downloads/'+fileName) 
    await xlsxFile("C:/Users/"+os.userInfo().username+"/Downloads/"+fileName).then((rows) => {   
      expectedColumnName = expectedColumnName.split(",");
      for (let i=0;i<=0;i++){
        for (let j=0;j<expectedColumnName.length;j++){
          var actualColumnName = rows[i][j];
          console.log(actualColumnName);
          console.log(expectedColumnName[j]);
            if((actualColumnName===expectedColumnName[j])|| ((actualColumnName===null && expectedColumnName[j]==="null"))){
              result =true
            } else {
              result =false
              break
            }  
        }
      }
    })
    console.log(result)
    return result;
  }
/**
   * This function will return the number of rows from the excel
   */
    async getRowCountFromExcel() {
      var fileName =await this.getMostRecentDownloadedFileName();
          var XLSX = require('xlsx');
          var workbook = XLSX.readFile("C:/Users/"+os.userInfo().username+"/Downloads/"+fileName);
          var sheet_name_list = workbook.SheetNames;
          let count = [];
          for (var sheetIndex = 0; sheetIndex < sheet_name_list.length; sheetIndex++) {
              var worksheet = workbook.Sheets[sheet_name_list[sheetIndex]];
              var range = XLSX.utils.decode_range(worksheet['!ref']);
              var num_rows = range.e.r - range.s.r + 1;
              console.log(num_rows)
              count.push({
                  data_count: num_rows
              });
          }
          console.log(count)
          return count;
      }

  /**
   * This function will return the latest downloaded file name from the local system
   */
  async getMostRecentDownloadedFileName() {
    let dir = "C:/Users/"+os.userInfo().username+"/Downloads"
    var files = fileSystem.readdirSync(dir);
    return _.max(files, function (f) {
        var fullpath = path.join(dir, f);
        return fileSystem.statSync(fullpath).ctime;
    });
  }
 
}


