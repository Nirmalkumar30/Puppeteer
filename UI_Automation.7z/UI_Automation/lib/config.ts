import params from './params.json';

const defaultConfig = params.bblogTest;
const environment: string = process.env.NODE_ENV
const environmentConfig = params[environment];
environmentConfig.featureFileTag = process.env.TAG || '@TestAssessment';
environmentConfig.username = process.env.USERNAME;
environmentConfig.password = process.env.PASSWORD || defaultConfig.password;
environmentConfig.serverDelayWaitTimeout = process.env.SERVERDELAYWAITTIMEOUT || 2000;
environmentConfig.baseUrl = process.env.BASEURL || defaultConfig.baseUrl ;
const finalConfig = Object.assign(defaultConfig, environmentConfig);

export class Config {

    baseUrl: string = environmentConfig.baseUrl
    userName: string = environmentConfig.username
    password: string = environmentConfig.password
    connectionString: string = finalConfig.connectionString
    isHeadless: boolean =  false
    slowMo: number = 2
    isDevTools: boolean = false
    launchTimeout: number =  1000000
    waitingTimeout: number =  30000
    viewPortWidth: number =  1920
    viewPortHeight: number =  1080

}