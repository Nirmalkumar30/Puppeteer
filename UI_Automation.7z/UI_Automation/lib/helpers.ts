import { setDefaultTimeout } from "cucumber";
import puppeteer, { Browser, Page, ElementHandle } from "puppeteer";
import { Config } from "./config";
import { assert } from "chai";
import * as fs from 'fs';

var browser: Browser;
var page: Page;
var file = process.cwd() + "/consolelog.txt";
var logs: string;
var config = new Config();
export class Helpers {

  async launchBrowser() {
    browser = await puppeteer.launch({
      headless: config.isHeadless,
      slowMo: config.slowMo,
      devtools: config.isDevTools,
      timeout: config.launchTimeout,
      args: [
        "--start-maximized",
        '--bypass-app-banner-engagement-checks ',
        // '--incognito'
      ]
    });
    page = (await browser.pages())[0];
    await this.addListeners();
    setDefaultTimeout(config.waitingTimeout);
    await page.setViewport({
      width: config.viewPortWidth,
      height: config.viewPortHeight
    });
  }

  async addListeners() {
    var tempStr: string;
    page.on('console', message => {
      tempStr = '\n' + page.url() + '\n' + message.type().toUpperCase() + " " + message.text() + '\n';

      if (logs == null) {
        logs += '\n' + page.url() + '\n' + message.type().toUpperCase() + " " + message.text() + '\n';
      }
      else if (!logs.includes(tempStr)) {
        logs += '\n' + page.url() + '\n' + message.type().toUpperCase() + " " + message.text() + '\n';
      }
    });
  }

  async scrollDown() {
    await page.evaluate(() => {
      window.scrollBy(0, window.innerHeight);
    });
  }

  async takeScreenshot() {
    const screenshot = await page.screenshot();
    return screenshot;
  }

  async closeBrowser() {
    await browser.close();
  }

  async refreshBrowser() {
    await page.reload({ waitUntil: "load" });
  }

  async executeJSscript(JSscript: string, selector: string) {
    document.body.scrollIntoView(true)
    document.execCommand(JSscript, false, selector);
  }

  async loadUrl(url: string) {
    await page.authenticate({'username':'candidatex', 'password': 'qa-is-cool'});
    await page.goto(url, { waitUntil: "load", timeout: 0 });
  }

  async isPresent(selector: string) {
    if (selector.includes("//")) {
      try {
        await page.waitForXPath(selector, { visible: true, timeout: 2000 });
        return true;
      }
      catch (e) {
        return false;
      }
    }
    else {
      try {
        await page.waitForSelector(selector, { timeout: 2000 });
        return true;
      }
      catch{
        return false;
      }
    }
  }

  async waitFor(waitTime: number) {
    await page.waitFor(waitTime);
  }

  async waitForText(selector: string, text: string) {
    try {
      await page.waitForSelector(selector);
      await page.waitForFunction(
        (selector, text) =>
          document.querySelector(selector).innerText.includes(text),
        {},
        selector,
        text
      );
    } catch (e) {
      throw new Error("Text: " + text + " not found for selector: " + selector);
    }
  }

  async elementShouldExist(locator: string) {
    try {
      if (locator.includes("//") || locator.includes("xpath_")) {
        await page.waitForXPath(locator, { visible: true, timeout: config.waitingTimeout });
      }
      else {
        await page.waitForSelector(locator, { visible: true, timeout: config.waitingTimeout });
      }
      return true;
    }
    catch (e) {
      assert.fail("Selector: " + locator + " does not exist");
    }
  }

  async elementShouldNotExist(locator: string) {
    try {
      if (locator.includes('//')) {
        await page.waitForXPath(locator, { hidden: true });
      } else {
        await page.waitForSelector(locator, { hidden: true });
      }
    } catch (e) {
      assert.fail('Element: ' + locator + ' does exist');
    }
  }

  getCurrentURL(): string {
    return page.url();
  }

  async waitForPageLoading() {
    const checkDurationMsecs = 1000;
    const maxChecks = config.waitingTimeout / checkDurationMsecs;
    let lastHTMLSize = 0;
    let checkCounts = 1;
    let countStableSizeIterations = 0;
    const minStableSizeIterations = 5;
    while (checkCounts++ <= maxChecks) {
      let html = await page.content();
      let currentHTMLSize = html.length;
      if (lastHTMLSize != 0 && currentHTMLSize == lastHTMLSize)
        countStableSizeIterations++;
      else
        countStableSizeIterations = 0; //reset the counter
      if (countStableSizeIterations >= minStableSizeIterations) {
        break;
      }
      lastHTMLSize = currentHTMLSize;
      await page.waitFor(checkDurationMsecs);
    }
  }

  async waitForNavigation() {
    await page.waitForNavigation({ waitUntil: ['load', 'domcontentloaded'] });
  }

  async clickOnElement(locator: string, index = 0) {
    try {
      var element;
      await this.waitFor(1000)
      await this.elementShouldExist(locator);
      if (locator.includes('//')) {
        element = await page.$x(locator);
      } else {
        element = await page.$$(locator);
      }
      await element[index].click();
    } catch (e) {
      assert.fail('Unable to click on element: ' + locator);
    }
  }

  async openNewTab() {
    page = await browser.newPage();
    setDefaultTimeout(config.waitingTimeout);
    await page.setViewport({
      width: config.viewPortWidth,
      height: config.viewPortHeight
    });
    return page;
  }

  async switchTab(index: number) {
    page = (await browser.pages())[index];
  }

  async closePage() {
    await page.close();
  }


  async enterText(locator: string, value: string, index = 0) {
    try {
      var element;
      await this.elementShouldExist(locator);
      if (locator.includes('//')) {
        element = await page.$x(locator);
      } else {
        element = await page.$$(locator);
      }
      await element[index].type(value);
    } catch (e) {
      assert.fail('Unable to enter text on element: ' + locator);
    }
  }

  async clearTextBox(locator: string) {
    try {
      var index = 0
      var element;
      await this.elementShouldExist(locator);
      if (locator.includes('//')) {
        element = await page.$x(locator);
      } else {
        element = await page.$$(locator);
      }
      await element[index].click({ clickCount: 3 });
      await page.keyboard.press('Backspace');
    } catch (e) {
      assert.fail('Unable to clear text of element: ' + locator);
    }
  }

  async goBack() {
    await page.goBack();
  }

  async waitForNewTab() {
    const getNewPageWhenLoaded = async () => {
      return new Promise(x =>
        browser.on('targetcreated', async target => {
          if (target.type() === 'page') {
            const newPage = await target.page();
            const newPagePromise = new Promise(y =>
              newPage.once('domcontentloaded', () => y(newPage))
            );
            const isPageLoaded = await newPage.evaluate(
              () => document.readyState
            );
            return isPageLoaded.match('complete|interactive')
              ? x(newPage)
              : x(newPagePromise);
          }
        })
      );
    };
    await getNewPageWhenLoaded();
  }
}
