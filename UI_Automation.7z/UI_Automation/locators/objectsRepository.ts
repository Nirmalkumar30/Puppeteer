export enum loginPageElements {
  txtUsername = "//input[@placeholder='Username']",
  txtPasswrod = "//input[@type='password']",
  btnLogin = "//button[@type='submit']",
}

export enum landingPageElements {
  lnkProfileName = "//a[@href='#/profile/{params}']",
  lnkNewPost = "//a[@href='#/editor']",
  lnkSettings = "//a[@href='#/settings']"
}

export enum editorPageElements {
  txtArticleTitle = "//input[@placeholder='Article Title']",
  txtArticleAbout = "//input[contains(@placeholder,'this article about?')]",
  txtMessage = "//textarea[@placeholder='Write your article (in markdown)']",
  txtEnterTags = "//input[@placeholder='Enter Tags']",
  btnPublish = "//button[@type='button']",
}

export enum articlePageElements {
  lblTitleName = "//h1[text()='{params}']",
  lnkFirstArticle = "(//h1[text()='{params}'])[1]",
  btnEditArticle = "(//a[text()=' Edit Article '])[1]",
  btnDeleteArticle = "(//button[text()=' Delete Article '])[1]",
  btnFavoriate = "(//button[@class='btn btn-sm pull-xs-right btn-outline-primary'])[1]",
  lnkFavoriateArticle = "//a[text()='Favorited Articles']",
  lnkArticleMessage = "(//p[contains(text(),'{params}')])[1]",
  lblUserNameHeader = "//h4[text()='{params}']",
  lblBio = "//p[text()='{params}']"
}

export enum settingsPageElements {
  txtProfilePic = "//input[@placeholder='URL of profile picture']",
  txtUserName = "//input[@placeholder='Your Name']",
  txtShortBio = "//textarea[@placeholder='Short bio about you']",
  txtemail = "//input[@placeholder='Email']",
  txtNewPassword = "//input[@placeholder='New Password']",
  btnUpdate = "//button[@type='submit']",
  btnLogout = "//button[text()=' Or click here to logout. ']",
}

