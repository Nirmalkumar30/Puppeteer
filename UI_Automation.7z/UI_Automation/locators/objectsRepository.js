"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingsPageElements = exports.articlePageElements = exports.editorPageElements = exports.landingPageElements = exports.loginPageElements = void 0;
var loginPageElements;
(function (loginPageElements) {
    loginPageElements["txtUsername"] = "//input[@placeholder='Username']";
    loginPageElements["txtPasswrod"] = "//input[@type='password']";
    loginPageElements["btnLogin"] = "//button[@type='submit']";
})(loginPageElements = exports.loginPageElements || (exports.loginPageElements = {}));
var landingPageElements;
(function (landingPageElements) {
    landingPageElements["lnkProfileName"] = "//a[@href='#/profile/{params}']";
    landingPageElements["lnkNewPost"] = "//a[@href='#/editor']";
    landingPageElements["lnkSettings"] = "//a[@href='#/settings']";
})(landingPageElements = exports.landingPageElements || (exports.landingPageElements = {}));
var editorPageElements;
(function (editorPageElements) {
    editorPageElements["txtArticleTitle"] = "//input[@placeholder='Article Title']";
    editorPageElements["txtArticleAbout"] = "//input[contains(@placeholder,'this article about?')]";
    editorPageElements["txtMessage"] = "//textarea[@placeholder='Write your article (in markdown)']";
    editorPageElements["txtEnterTags"] = "//input[@placeholder='Enter Tags']";
    editorPageElements["btnPublish"] = "//button[@type='button']";
})(editorPageElements = exports.editorPageElements || (exports.editorPageElements = {}));
var articlePageElements;
(function (articlePageElements) {
    articlePageElements["lblTitleName"] = "//h1[text()='{params}']";
    articlePageElements["lnkFirstArticle"] = "(//h1[text()='{params}'])[1]";
    articlePageElements["btnEditArticle"] = "(//a[text()=' Edit Article '])[1]";
    articlePageElements["btnDeleteArticle"] = "(//button[text()=' Delete Article '])[1]";
    articlePageElements["btnFavoriate"] = "(//button[@class='btn btn-sm pull-xs-right btn-outline-primary'])[1]";
    articlePageElements["lnkFavoriateArticle"] = "//a[text()='Favorited Articles']";
    articlePageElements["lnkArticleMessage"] = "(//p[contains(text(),'{params}')])[1]";
    articlePageElements["lblUserNameHeader"] = "//h4[text()='{params}']";
    articlePageElements["lblBio"] = "//p[text()='{params}']";
})(articlePageElements = exports.articlePageElements || (exports.articlePageElements = {}));
var settingsPageElements;
(function (settingsPageElements) {
    settingsPageElements["txtProfilePic"] = "//input[@placeholder='URL of profile picture']";
    settingsPageElements["txtUserName"] = "//input[@placeholder='Your Name']";
    settingsPageElements["txtShortBio"] = "//textarea[@placeholder='Short bio about you']";
    settingsPageElements["txtemail"] = "//input[@placeholder='Email']";
    settingsPageElements["txtNewPassword"] = "//input[@placeholder='New Password']";
    settingsPageElements["btnUpdate"] = "//button[@type='submit']";
    settingsPageElements["btnLogout"] = "//button[text()=' Or click here to logout. ']";
})(settingsPageElements = exports.settingsPageElements || (exports.settingsPageElements = {}));
//# sourceMappingURL=objectsRepository.js.map