"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LandingPage = void 0;
const helpers_1 = require("../../lib/helpers");
const objectsRepository_1 = require("../../locators/objectsRepository");
var browserActions = new helpers_1.Helpers();
class LandingPage {
    clickNewPost() {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.clickOnElement(objectsRepository_1.landingPageElements.lnkNewPost);
        });
    }
    ;
    verifyUserName(userName) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield browserActions.isPresent(objectsRepository_1.landingPageElements.lnkProfileName.replace('{params}', userName));
        });
    }
    clickUserName(userName) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield browserActions.clickOnElement(objectsRepository_1.landingPageElements.lnkProfileName.replace('{params}', userName));
        });
    }
    clickSetting() {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.waitFor(1000);
            yield browserActions.clickOnElement(objectsRepository_1.landingPageElements.lnkSettings);
        });
    }
    ;
}
exports.LandingPage = LandingPage;
//# sourceMappingURL=LandingPage.js.map