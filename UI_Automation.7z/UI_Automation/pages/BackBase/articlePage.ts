import { Helpers } from '../../lib/helpers';
import { articlePageElements } from '../../locators/objectsRepository';

var browserActions = new Helpers();
export class articlePage {

    async verifyTitleName(titleName) {
        await browserActions.waitFor(1000)
        return await browserActions.isPresent(articlePageElements.lblTitleName.replace('{params}',titleName ))
    }

    async selectFirstArticle(titleName) {
        return await browserActions.clickOnElement(articlePageElements.lnkFirstArticle.replace('{params}',titleName ))
    }

    async clickEditArticle() {
        return await browserActions.clickOnElement(articlePageElements.btnEditArticle)
    }

    async clickDeleteArticle() {
        return await browserActions.clickOnElement(articlePageElements.btnDeleteArticle)
    }


    async verifyArticleMessage(titleMessage) {
        await browserActions.waitFor(4000)
        return await browserActions.isPresent(articlePageElements.lnkArticleMessage.replace('{params}',titleMessage ))
    }

    async selectFavorateArticle() {
        return await browserActions.clickOnElement(articlePageElements.btnFavoriate)
    }

    async clickFavArticleTab() {
        return await browserActions.clickOnElement(articlePageElements.lnkFavoriateArticle)
    }

}
