import { Helpers } from '../../lib/helpers';
import { loginPageElements } from '../../locators/objectsRepository';
import { Config } from "../../lib/config";

var browserActions = new Helpers();
var config = new Config();
export class LoginPage {

  async loginApplication(url: string) {
    await browserActions.loadUrl(url);
    await browserActions.enterText(loginPageElements.txtUsername, config.userName);
    await browserActions.enterText(loginPageElements.txtPasswrod, config.password);
    await browserActions.waitFor(1000)
    await browserActions.clickOnElement(loginPageElements.btnLogin);
  }
}
