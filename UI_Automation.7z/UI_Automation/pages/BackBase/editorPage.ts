import { Helpers } from '../../lib/helpers';
import { editorPageElements } from '../../locators/objectsRepository';

var browserActions = new Helpers();
export class editorPage {

    async enterArticleTitle(titleName) {
        await browserActions.enterText(editorPageElements.txtArticleTitle,titleName)
    };

    async enterArticleAbout(titleAbout) {
        await browserActions.enterText(editorPageElements.txtArticleAbout,titleAbout)
    };

    async enterArticleMessage(titleMessage) {
        await browserActions.waitFor(2000)
        await browserActions.enterText(editorPageElements.txtMessage,titleMessage)
    };

    async enterTagName(tagName) {
        await browserActions.enterText(editorPageElements.txtEnterTags,tagName)
    };

    async clickPublishArticle() {
        await browserActions.clickOnElement(editorPageElements.btnPublish)
    };
}
