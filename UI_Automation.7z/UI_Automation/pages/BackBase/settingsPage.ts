import { Helpers } from '../../lib/helpers';
import { settingsPageElements ,articlePageElements,loginPageElements, landingPageElements } from '../../locators/objectsRepository';
import { Config } from "../../lib/config";

var browserActions = new Helpers();
var config = new Config();

export class settingsPage {

    async enterProfileUrl(url) {
        await browserActions.enterText(settingsPageElements.txtProfilePic,url)
    };

    async enterUserName(userName) {
        await browserActions.clearTextBox(settingsPageElements.txtUserName)
        await browserActions.enterText(settingsPageElements.txtUserName,userName)
    };

    async enterEmail(email) {
        await browserActions.clearTextBox(settingsPageElements.txtemail)
        await browserActions.enterText(settingsPageElements.txtemail,email)
    };

    async enterShortBio(Bio) {
        await browserActions.clearTextBox(settingsPageElements.txtShortBio)
        await browserActions.enterText(settingsPageElements.txtShortBio,Bio)
    };

    async enterPassword(password) {
        await browserActions.enterText(settingsPageElements.txtNewPassword,password)
    };

    async clickUpdate() {
        await browserActions.clickOnElement(settingsPageElements.btnUpdate)
    };

    async clickLogout() {
        await browserActions.clickOnElement(settingsPageElements.btnLogout)
    };

    async VerifyNewUserName(userName) {
        await browserActions.waitFor(2000)
        return await browserActions.isPresent(articlePageElements.lblUserNameHeader.replace('{params}', userName))
    };

    async VerifyBio(userName) {
        await browserActions.waitFor(1000)
        return await browserActions.isPresent(articlePageElements.lblBio.replace('{params}', userName))
    };

    async verifyEmail(userName) {
        await browserActions.clickOnElement(settingsPageElements.btnLogout)
        await browserActions.enterText(loginPageElements.txtUsername, userName);
        await browserActions.enterText(loginPageElements.txtPasswrod, config.password);
        await browserActions.clickOnElement(loginPageElements.btnLogin);
        return await browserActions.isPresent(landingPageElements.lnkNewPost)
    };

}
