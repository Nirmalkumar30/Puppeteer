"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.editorPage = void 0;
const helpers_1 = require("../../lib/helpers");
const objectsRepository_1 = require("../../locators/objectsRepository");
var browserActions = new helpers_1.Helpers();
class editorPage {
    enterArticleTitle(titleName) {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.enterText(objectsRepository_1.editorPageElements.txtArticleTitle, titleName);
        });
    }
    ;
    enterArticleAbout(titleAbout) {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.enterText(objectsRepository_1.editorPageElements.txtArticleAbout, titleAbout);
        });
    }
    ;
    enterArticleMessage(titleMessage) {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.waitFor(2000);
            yield browserActions.enterText(objectsRepository_1.editorPageElements.txtMessage, titleMessage);
        });
    }
    ;
    enterTagName(tagName) {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.enterText(objectsRepository_1.editorPageElements.txtEnterTags, tagName);
        });
    }
    ;
    clickPublishArticle() {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.waitFor(1000);
            yield browserActions.clickOnElement(objectsRepository_1.editorPageElements.btnPublish);
        });
    }
    ;
}
exports.editorPage = editorPage;
//# sourceMappingURL=editorPage.js.map