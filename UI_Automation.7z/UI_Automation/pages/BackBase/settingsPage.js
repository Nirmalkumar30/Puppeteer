"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingsPage = void 0;
const helpers_1 = require("../../lib/helpers");
const objectsRepository_1 = require("../../locators/objectsRepository");
const config_1 = require("../../lib/config");
var browserActions = new helpers_1.Helpers();
var config = new config_1.Config();
class settingsPage {
    enterProfileUrl(url) {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.enterText(objectsRepository_1.settingsPageElements.txtProfilePic, url);
        });
    }
    ;
    enterUserName(userName) {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.clearTextBox(objectsRepository_1.settingsPageElements.txtUserName);
            yield browserActions.enterText(objectsRepository_1.settingsPageElements.txtUserName, userName);
        });
    }
    ;
    enterEmail(email) {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.clearTextBox(objectsRepository_1.settingsPageElements.txtemail);
            yield browserActions.enterText(objectsRepository_1.settingsPageElements.txtemail, email);
        });
    }
    ;
    enterShortBio(Bio) {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.clearTextBox(objectsRepository_1.settingsPageElements.txtShortBio);
            yield browserActions.enterText(objectsRepository_1.settingsPageElements.txtShortBio, Bio);
        });
    }
    ;
    enterPassword(password) {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.enterText(objectsRepository_1.settingsPageElements.txtNewPassword, password);
        });
    }
    ;
    clickUpdate() {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.waitFor(1000);
            yield browserActions.clickOnElement(objectsRepository_1.settingsPageElements.btnUpdate);
        });
    }
    ;
    clickLogout() {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.waitFor(1000);
            yield browserActions.clickOnElement(objectsRepository_1.settingsPageElements.btnLogout);
        });
    }
    ;
    VerifyNewUserName(userName) {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.waitFor(2000);
            return yield browserActions.isPresent(objectsRepository_1.articlePageElements.lblUserNameHeader.replace('{params}', userName));
        });
    }
    ;
    VerifyBio(userName) {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.waitFor(1000);
            return yield browserActions.isPresent(objectsRepository_1.articlePageElements.lblBio.replace('{params}', userName));
        });
    }
    ;
    verifyEmail(userName) {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.waitFor(1000);
            yield browserActions.clickOnElement(objectsRepository_1.settingsPageElements.btnLogout);
            yield browserActions.enterText(objectsRepository_1.loginPageElements.txtUsername, userName);
            yield browserActions.enterText(objectsRepository_1.loginPageElements.txtPasswrod, config.password);
            yield browserActions.waitFor(1000);
            yield browserActions.clickOnElement(objectsRepository_1.loginPageElements.btnLogin);
            return yield browserActions.isPresent(objectsRepository_1.landingPageElements.lnkNewPost);
        });
    }
    ;
}
exports.settingsPage = settingsPage;
//# sourceMappingURL=settingsPage.js.map