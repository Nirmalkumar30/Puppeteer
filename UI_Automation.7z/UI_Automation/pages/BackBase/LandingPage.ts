import { Helpers } from '../../lib/helpers';
import { landingPageElements } from '../../locators/objectsRepository';

var browserActions = new Helpers();

export class LandingPage {

    async clickNewPost() {
        await browserActions.clickOnElement(landingPageElements.lnkNewPost)
    };

    async verifyUserName(userName) {
        return await browserActions.isPresent(landingPageElements.lnkProfileName.replace('{params}', userName))
    }

    async clickUserName(userName) {
        return await browserActions.clickOnElement(landingPageElements.lnkProfileName.replace('{params}', userName))
    }

    async clickSetting() {
        await browserActions.clickOnElement(landingPageElements.lnkSettings)
    };
    
}
