"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.articlePage = void 0;
const helpers_1 = require("../../lib/helpers");
const objectsRepository_1 = require("../../locators/objectsRepository");
var browserActions = new helpers_1.Helpers();
class articlePage {
    // async clickTshirtSize(tshirtsize:string) {
    //     await browserActions.clickOnElement(flipcartElements.btnTshirtSize.replace('{params}', tshirtsize))
    // }
    // async clickAddTocart() {
    //     await browserActions.waitFor(2000)
    //     await browserActions.clickOnElement(flipcartElements.btnAddtoCart)
    // }
    // async clickHomeIcon() {
    //     await browserActions.clickOnElement(flipcartElements.imgFlipcartIcon)
    // }
    verifyTitleName(titleName) {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.waitFor(1000);
            return yield browserActions.isPresent(objectsRepository_1.articlePageElements.lblTitleName.replace('{params}', titleName));
        });
    }
    selectFirstArticle(titleName) {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.waitFor(1000);
            return yield browserActions.clickOnElement(objectsRepository_1.articlePageElements.lnkFirstArticle.replace('{params}', titleName));
        });
    }
    clickEditArticle() {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.waitFor(1000);
            return yield browserActions.clickOnElement(objectsRepository_1.articlePageElements.btnEditArticle);
        });
    }
    clickDeleteArticle() {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.waitFor(1000);
            return yield browserActions.clickOnElement(objectsRepository_1.articlePageElements.btnDeleteArticle);
        });
    }
    verifyArticleMessage(titleMessage) {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.waitFor(4000);
            return yield browserActions.isPresent(objectsRepository_1.articlePageElements.lnkArticleMessage.replace('{params}', titleMessage));
        });
    }
    selectFavorateArticle() {
        return __awaiter(this, void 0, void 0, function* () {
            yield browserActions.waitFor(1000);
            return yield browserActions.clickOnElement(objectsRepository_1.articlePageElements.btnFavoriate);
        });
    }
    clickFavArticleTab() {
        return __awaiter(this, void 0, void 0, function* () {
            return yield browserActions.clickOnElement(objectsRepository_1.articlePageElements.lnkFavoriateArticle);
        });
    }
}
exports.articlePage = articlePage;
//# sourceMappingURL=articlePage.js.map